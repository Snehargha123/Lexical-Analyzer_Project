#include "lexer.h"


static const char *keywords[] =
{
    "auto",
    "break",
    "case",
    "char",
    "const",
    "continue",
    "default",
    "do",
    "double",
    "else",
    "enum",
    "extern",
    "float",
    "for",
    "goto",
    "if",
    "int",
    "long",
    "register",
    "return",
    "short",
    "signed",
    "sizeof",
    "static",
    "struct",
    "switch",
    "typedef",
    "union",
    "unsigned",
    "void",
    "volatile",
    "while"
};

#define KEYWORD_COUNT (sizeof(keywords) / sizeof(keywords[0]))

/* --------------------------------------------------
   Check whether a word is a keyword
   -------------------------------------------------- */

static int is_keyword(const char *word)
{
    int i;

    for (i = 0; i < KEYWORD_COUNT; i++)
    {
        if (strcmp(word, keywords[i]) == 0)
        {
            return 1;
        }
    }

    return 0;
}

/* --------------------------------------------------
   Check whether character is a special character
   -------------------------------------------------- */

static int is_special_character(int ch)
{
    switch (ch)
    {
        case '(':
        case ')':
        case '{':
        case '}':
        case '[':
        case ']':
        case ';':
        case ',':
        case ':':
        case '?':
            return 1;

        default:
            return 0;
    }
}

/* --------------------------------------------------
   Check whether character can start an operator
   -------------------------------------------------- */

static int is_operator_start(int ch)
{
    switch (ch)
    {
        case '+':
        case '-':
        case '*':
        case '/':
        case '%':
        case '=':
        case '<':
        case '>':
        case '!':
        case '&':
        case '|':
        case '^':
        case '~':
            return 1;

        default:
            return 0;
    }
}

/* --------------------------------------------------
   Process identifier / keyword
   -------------------------------------------------- */

static void process_identifier(FILE *fp, int ch)
{
    char word[100];
    int i = 0;

    while (isalnum(ch) || ch == '_')
    {
        if (i < 99)
        {
            word[i++] = ch;
        }

        ch = fgetc(fp);
    }

    word[i] = '\0';

    if (ch != EOF)
    {
        ungetc(ch, fp);
    }

    if (is_keyword(word))
    {
        printf("Keyword      : %s\n", word);
    }
    else
    {
        printf("Identifier   : %s\n", word);
    }
}

/* --------------------------------------------------
   Process integer / floating-point constant
   -------------------------------------------------- */

static void process_number(FILE *fp, int ch)
{
    char number[100];
    int i = 0;
    int dot_count = 0;

    while (isdigit(ch) || ch == '.')
    {
        if (ch == '.')
        {
            dot_count++;
        }

        if (i < 99)
        {
            number[i++] = ch;
        }

        ch = fgetc(fp);
    }

    number[i] = '\0';


    if (ch != EOF)
    {
        ungetc(ch, fp);
    }

    if (dot_count == 0)
    {
        printf("Constant     : %s\n", number);
    }
    else if (dot_count == 1)
    {
        printf("Float        : %s\n", number);
    }
    else
    {
        printf("Lexical Error: Invalid number %s\n", number);
    }
}

/* --------------------------------------------------
   Process string literal
   -------------------------------------------------- */

static void process_string(FILE *fp)
{
    char str[200];
    int ch;
    int i = 0;

    str[i++] = '"';

    while ((ch = fgetc(fp)) != EOF)
    {
        if (i < 199)
        {
            str[i++] = ch;
        }


        if (ch == '"')
        {
            break;
        }


        if (ch == '\n')
        {
            break;
        }
    }

    str[i] = '\0';

    if (ch == '"')
    {
        printf("String       : %s\n", str);
    }
    else
    {
        printf("Lexical Error: Unterminated string\n");
    }
}

/* --------------------------------------------------
   Process character literal
   -------------------------------------------------- */

static void process_character(FILE *fp)
{
    char character[20];
    int ch;
    int i = 0;

    character[i++] = '\'';

    while ((ch = fgetc(fp)) != EOF)
    {
        if (i < 19)
        {
            character[i++] = ch;
        }

        if (ch == '\'')
        {
            break;
        }

        if (ch == '\n')
        {
            break;
        }
    }

    character[i] = '\0';

    if (ch == '\'')
    {
        printf("Character    : %s\n", character);
    }
    else
    {
        printf("Lexical Error: Unterminated character literal\n");
    }
}

/* --------------------------------------------------
   Process preprocessor directive
   -------------------------------------------------- */

static void process_preprocessor(FILE *fp)
{
    char directive[200];
    int ch;
    int i = 0;

    directive[i++] = '#';

    while ((ch = fgetc(fp)) != EOF && ch != '\n')
    {
        if (i < 199)
        {
            directive[i++] = ch;
        }
    }

    directive[i] = '\0';

    printf("Preprocessor : %s\n", directive);
}

/* --------------------------------------------------
   Process single-line comment
   -------------------------------------------------- */

static void process_single_line_comment(FILE *fp)
{
    int ch;

    while ((ch = fgetc(fp)) != EOF)
    {
        if (ch == '\n')
        {
            break;
        }
    }
}

/* --------------------------------------------------
   Process multi-line comment
   -------------------------------------------------- */

static void process_multi_line_comment(FILE *fp)
{
    int ch;
    int previous = 0;


    while ((ch = fgetc(fp)) != EOF)
    {
        if (previous == '*' && ch == '/')
        {
            break;
        }

        previous = ch;
    }

    if (ch == EOF)
    {
        printf("Lexical Error: Unterminated multi-line comment\n");
    }
}

/* --------------------------------------------------
   Process operators
   -------------------------------------------------- */

static void process_operator(FILE *fp, int ch)
{
    int next;

    next = fgetc(fp);

    /*
       Two-character operators
    */

    if (ch == '+' && next == '+')
    {
        printf("Operator     : ++\n");
    }
    else if (ch == '-' && next == '-')
    {
        printf("Operator     : --\n");
    }
    else if (ch == '=' && next == '=')
    {
        printf("Operator     : ==\n");
    }
    else if (ch == '!' && next == '=')
    {
        printf("Operator     : !=\n");
    }
    else if (ch == '<' && next == '=')
    {
        printf("Operator     : <=\n");
    }
    else if (ch == '>' && next == '=')
    {
        printf("Operator     : >=\n");
    }
    else if (ch == '&' && next == '&')
    {
        printf("Operator     : &&\n");
    }
    else if (ch == '|' && next == '|')
    {
        printf("Operator     : ||\n");
    }
    else if (ch == '+' && next == '=')
    {
        printf("Operator     : +=\n");
    }
    else if (ch == '-' && next == '=')
    {
        printf("Operator     : -=\n");
    }
    else if (ch == '*' && next == '=')
    {
        printf("Operator     : *=\n");
    }
    else if (ch == '/' && next == '=')
    {
        printf("Operator     : /=\n");
    }
    else if (ch == '%' && next == '=')
    {
        printf("Operator     : %=\n");
    }
    else if (ch == '&' && next == '=')
    {
        printf("Operator     : &=\n");
    }
    else if (ch == '|' && next == '=')
    {
        printf("Operator     : |=\n");
    }
    else if (ch == '^' && next == '=')
    {
        printf("Operator     : ^=\n");
    }
    else if (ch == '<' && next == '<')
    {
        printf("Operator     : <<\n");
    }
    else if (ch == '>' && next == '>')
    {
        printf("Operator     : >>\n");
    }
    else
    {

        if (next != EOF)
        {
            ungetc(next, fp);
        }

        printf("Operator     : %c\n", ch);
    }
}

/* --------------------------------------------------
   Main lexical analyzer
   -------------------------------------------------- */

void lexical_analyzer(FILE *fp)
{
    int ch;
    int next;

    while ((ch = fgetc(fp)) != EOF)
    {

        if (isspace(ch))
        {
            continue;
        }

        if (ch == '#')
        {
            process_preprocessor(fp);
            continue;
        }

        if (isalpha(ch) || ch == '_')
        {
            process_identifier(fp, ch);
            continue;
        }

        if (isdigit(ch))
        {
            process_number(fp, ch);
            continue;
        }


        if (ch == '"')
        {
            process_string(fp);
            continue;
        }


        if (ch == '\'')
        {
            process_character(fp);
            continue;
        }

    

        if (ch == '/')
        {
            next = fgetc(fp);

            if (next == '/')
            {
                process_single_line_comment(fp);
                continue;
            }
            else if (next == '*')
            {
                process_multi_line_comment(fp);
                continue;
            }
            else
            {
                if (next != EOF)
                {
                    ungetc(next, fp);
                }

                process_operator(fp, ch);
                continue;
            }
        }

        if (is_operator_start(ch))
        {
            process_operator(fp, ch);
            continue;
        }


        if (is_special_character(ch))
        {
            printf("Special Char : %c\n", ch);
            continue;
        }

        printf("Lexical Error: Invalid character '%c'\n", ch);
    }
}