#include<stdio.h>
#include<string.h>

void string(char *str)
{
  
  while(*str != '\0')
  {
   printf("%c ", *str);
   str++; 
  }
}

  
int main() {

char str[40];
int a = 20;

scanf("%[^\n]", str);
printf("%d\n", strlen(str));
printf("a = %d\n", a);

string(str);

return 0;

}
