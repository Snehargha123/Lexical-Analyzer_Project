#include <stdio.h>
#include "lexer.h"

int main(int argc, char *argv[])
{
    FILE *fp;

    if (argc != 2)
    {
        printf("Usage: ./a.out <file.c>\n");
        return 1;
    }

    fp = fopen(argv[1], "r");

    if (fp == NULL)
    {
        printf("ERROR: Unable to open file\n");
        return 1;
    }

    printf("Open : %s Success\n", argv[1]);
    printf("Parsing : %s Started\n", argv[1]);

    lexical_analyzer(fp);

    printf("Parsing : %s Done\n", argv[1]);

    fclose(fp);

    return 0;
}